﻿/**
 * @file FlexLexer.h
 * @author zenglj (zenglj@nwpu.edu.cn)
 * @brief 词法分析共同头文件
 * @version 0.1
 * @date 2023-09-24
 *
 * @copyright Copyright (c) 2023
 *
 */
#pragma once

#include "MiniCFlex.h"
